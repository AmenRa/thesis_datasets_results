NB: Non ho potuto far girare la rete neurale che avevo usato perché mi da errore l'import da scikit-learn, i risultati di quella sono in tesi

I nomi dei file nelle cartelle corrispondono al numero nella bibliografia degli articoli da cui gli approcci sono presi.

Nei vari file è comunque riportato il titolo dell'articolo.

Cosa “buffa”: con XGBoost il mio approccio risulta essere il migliore in tutti i confronti con la letteratura.....

Tutti gli esperimenti sono stati condotti su una macchina con sistema operativo Ubuntu 16.04, utilizzando scikit-learn e XGBoost.

original_dataset: descritto in 3.3, utilizzato negli esperimenti 1, 2, 5
refined_dataset: descritto in 3.3.1, utilizzato nell’esperimento 5
fa_non_fa_dataset: utilizzato nell’esperimento 3
high_low_dataset: utilizzato nell’esperimento 4
